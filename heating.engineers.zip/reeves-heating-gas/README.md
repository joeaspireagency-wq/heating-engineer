# Reeves Heating & Gas: website prototype

Frontend-only prototype for a fictional Gas Safe heating engineer (Bristol & Bath). All business details, reviews, prices and the phone number are placeholders.

## Use it
`index.html` is a complete, self-contained page (CSS, JS and photos inline). Open it in a browser, or host it as-is.

**GitHub Pages:** push this folder to a repo, then Settings → Pages → deploy from the `main` branch, root folder.

## Edit it
Source files are in `src/`:
- `style.css` – all styles
- `body.html` – page markup
- `app.js` – content config (`SITE` object), quote form and interactions
- `photo.js` – embedded photos (base64)
- `build.sh` – combines them into `../index.html` (`bash src/build.sh`)

Fonts (Plus Jakarta Sans, Inter, Caveat) load from Google Fonts.
