/* =====================================================================
   REEVES HEATING & GAS: prototype site logic
   Everything editable lives in SITE below (copy, prices, packages, reviews,
   images, persona). All prices, reviews, guarantees and results are
   FICTIONAL placeholder content for demonstration.
   ===================================================================== */
const SITE = {
  business: { name: 'Reeves Heating & Gas', owner: 'Callum Reeves', phone: '+44 7340 845320', phoneHref: '+447340845320',
    email: 'hello@reevesheating.example', gasSafeNumber: '000000' },
  areas: ['Bristol', 'Bath', 'Keynsham', 'Portishead', 'Clevedon', 'Yate'],
  areaNotes: { Bristol: 'Home base in Bedminster', Bath: 'City and surrounds', Keynsham: 'Between Bristol and Bath', Portishead: 'Down by the coast', Clevedon: 'North Somerset seafront', Yate: 'South Gloucestershire' },

  services: [
    { ico: 'wrench', title: 'Emergency boiler repair', benefit: 'No heating or hot water? We’ll get you warm again.',
      features: ['Same-day where possible', 'Fault diagnosed and priced before we fix', 'Common parts carried in the van'], price: '£95', priceNote: 'call-out' },
    { ico: 'boiler', title: 'Boiler installation & replacement', benefit: 'A new boiler, fitted properly in one day.',
      features: ['Free home survey and quote', 'Old boiler removed and disposed of', 'Gas Safe certificate and warranty registration'], price: '£2,200', priceNote: '' },
    { ico: 'clipboard', title: 'Annual boiler service', benefit: 'Keep it safe, efficient and under warranty.',
      features: ['Full safety and efficiency check', 'Written service record', 'Spot problems before they become breakdowns'], price: '£80', priceNote: '' },
    { ico: 'file-check', title: 'Landlord gas safety certificate (CP12)', benefit: 'Legal paperwork, sorted.',
      features: ['Certificate issued on the day', 'Reminder before it expires', 'Multi-property discounts'], price: '£65', priceNote: '' },
    { ico: 'droplets', title: 'Powerflush & system protection', benefit: 'Cold radiators? Slow heat-up? Sludge is usually why.',
      features: ['Cleans the whole system', 'Magnetic filter fitted', 'Quieter, more even heating'], price: '£450', priceNote: '' },
    { ico: 'radiator', title: 'Smart thermostats & radiators', benefit: 'Better control, lower bills.',
      features: ['Supply and fit', 'Walk-through of how to use it', 'New radiators and TRVs'], price: '£150', priceNote: 'thermostat fitted' }
  ],
  included: ['Free home survey and fixed-price quote', 'Old boiler removed and recycled', 'Magnetic system filter', 'Flue, pipework and controls fitted tidily',
    'Full commissioning and safety checks', 'Gas Safe certificate and Building Regs notification', 'Manufacturer warranty registered for you', 'Handover walk-through so you know how it all works'],

  includedIcons: ['clipboard', 'recycle', 'droplets', 'wrench', 'shield-check', 'file-check', 'badge-check', 'home'],

  packages: [
    { id: 'essential', name: 'Essential', price: '£2,200', blurb: 'A solid, no-frills replacement.',
      features: ['Quality combi boiler', 'Standard controls', 'Magnetic filter', '5-year warranty', 'Full commissioning'] },
    { id: 'comfort', name: 'Comfort', price: '£2,700', popular: true, blurb: 'What most of our customers choose.',
      features: ['Everything in Essential', 'Smart thermostat', 'System clean', 'Longer warranty, up to 10 years, registered for you', 'Priority callout for 12 months'] },
    { id: 'premium', name: 'Premium', price: '£3,400', blurb: 'The full works, done once.',
      features: ['Everything in Comfort', 'Powerflush', 'Upgraded radiators and TRVs', 'Free first annual service'] }
  ],

  promise: [
    ['Fixed price, agreed first', 'The price we quote is the price you pay. It only changes if you ask us to do more.'],
    ['Gas Safe Registered', 'Every job done by a Gas Safe engineer, with the paperwork to prove it.'],
    ['12-month workmanship guarantee', 'If something we’ve done isn’t right, we’ll come back and fix it at no cost.'],
    ['Manufacturer warranty on new boilers', 'Up to 10 years, depending on the boiler. We register it for you.'],
    ['On time, or we call ahead', 'We’ll give you a time window and ring before we arrive.'],
    ['Tidy and respectful', 'Dust sheets down, work area cleared, home left as we found it.']
  ],

  steps: [
    ['Request your quote', 'Tell us what’s wrong and where you are. It takes about 60 seconds.'],
    ['We call you within the hour', 'Callum or one of the team rings to talk it through and agree a time.'],
    ['Fixed price, fixed on the day', 'You get the price in writing before we start. You pay when the job is done.']
  ],

  caseStudy: {
    title: 'Bishopston, Bristol: old boiler to warm, quiet home',
    before: '1998 boiler, noisy, cold radiators, repair bills three winters running.',
    did: 'New Comfort package combi boiler, powerflush, smart thermostat. Done in 1 day.',
    stats: [['clock', '1 day', 'Fitted start to finish'], ['thermometer', 'Every room', 'Warm, even heat'], ['pound', '~25%', 'Lower bills (example)']],
    quote: 'We put up with a noisy boiler and cold radiators for years. Now the whole house is warm and I can’t even hear it run.',
    cite: 'Rachel & Dan P., Bishopston (demonstration quote)',
    small: 'Results vary by home. Fictional example for demonstration.'
  },

  reviews: [
    { name: 'Sarah T.', town: 'Southville, Bristol', job: 'Boiler repair', text: 'Boiler died on a Sunday morning in January. Callum was here by lunchtime, found the fault straight away and we were warm again before the kids got home. The price was exactly what he quoted.' },
    { name: 'James & Priya M.', town: 'Widcombe, Bath', job: 'New boiler', text: 'We had three quotes. Reeves was the only one who explained why our old boiler wasn’t worth repairing. Fitted in a day and the house was left spotless.' },
    { name: 'Mike D.', town: 'Keynsham', job: 'Annual service', text: 'Third year using them for our annual service. Always on time, and they tell me straight what needs doing and what doesn’t.' },
    { name: 'Helen R.', town: 'Portishead', job: 'Landlord certificates', text: 'I have three rental properties and they sort every gas safety certificate and remind me before they expire. Saves me a lot of hassle.' },
    { name: 'Tom & Aisha K.', town: 'Clevedon', job: 'Powerflush and radiators', text: 'The radiators were cold at the bottom for years. After the powerflush the whole house heats evenly and it’s so much quieter.' },
    { name: 'Gareth W.', town: 'Yate', job: 'Emergency repair', text: 'Boiler was losing pressure and leaking at 8pm. Called, and Callum was with us within the hour. Fixed it, explained what went wrong, no fuss.' }
  ],

  faq: [
    ['Is my boiler worth repairing, or should I replace it?', 'We’ll tell you honestly. If a repair makes sense we’ll fix it, and if the boiler is past its best we’ll explain why and show you the numbers. We’d rather you spend wisely than spend twice.'],
    ['Will the price change once you start, or are there hidden extras?', 'No. You get a fixed price in writing before we begin. It only changes if you ask us to do extra work.'],
    ['How do I know you’re properly qualified?', 'We’re Gas Safe Registered, which is a legal requirement for gas work. Check our ID card when we arrive, and you can verify any engineer on the Gas Safe Register.'],
    ['How quickly can you come out?', 'For breakdowns we aim for same-day where possible, and we’ll call you within the hour of your request to confirm a time.'],
    ['What if something goes wrong after the job?', 'Our work is covered by a 12-month workmanship guarantee, and new boilers carry the manufacturer’s warranty. If it isn’t right, we come back and put it right.'],
    ['How long will a new boiler take, and will it make a mess?', 'Most installs take one day. We lay dust sheets, keep the work area tidy and clear up before we leave.'],
    ['Can I spread the cost?', 'Yes, finance options are available on new boilers (placeholder). You pay on completion, with no large deposit upfront.']
  ],

  needs: [
    { id: 'no-heating', label: 'No heating', ico: 'thermometer' },
    { id: 'no-hot-water', label: 'No hot water', ico: 'droplets' },
    { id: 'leak-noise', label: 'Boiler leaking or noisy', ico: 'alert' },
    { id: 'service', label: 'Annual service', ico: 'clipboard' },
    { id: 'new', label: 'New boiler', ico: 'boiler' }
  ],
  urgency: [{ id: 'today', label: 'Today' }, { id: 'week', label: 'This week' }, { id: 'planning', label: 'Just planning' }],

  /* Image config: swap placeholders for real project photos by setting `src`.
     The page ships with original vector illustrations as clearly marked placeholders. */
  images: {
    // Hero background photo: src comes from HERO_PHOTO (embedded data URI in the script above). Swap for a file path to use your own.
    heroBg: { id: 'heroBg', src: HERO_PHOTO, alt: 'Engineer in a grey and navy uniform and blue gloves repairing a wall-mounted combi boiler', width: 1280, height: 655, focal: '30% 40%' },
    callum: { id: 'callum', src: CALLUM_PHOTO, alt: 'Callum Reeves, a smiling Gas Safe engineer in a hi-vis vest holding a tablet', width: 880, height: 1100, focal: '50% 25%' },
    before: { id: 'before', src: '', alt: 'Before: a 1998 boiler in a cupboard with untidy pipework and a cold radiator', width: 1600, height: 1000, focal: '50% 50%' },
    after:  { id: 'after',  src: '', alt: 'After: a new combi boiler in a tidy cupboard with neat pipework, a smart thermostat and a warm radiator', width: 1600, height: 1000, focal: '50% 50%' }
  }
};

/* ---------- tiny helpers ---------- */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;

const ICONS = {
  'flame': '<path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.07-2.14-.22-4.05 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.15.43-2.29 1-3a2.5 2.5 0 0 0 2.5 2.5z"/>',
  'shield-check': '<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/><path d="m9 12 2 2 4-4"/>',
  'star': '<path d="M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z"/>',
  'pound': '<path d="M18 7c0-5.333-8-5.333-8 0"/><path d="M10 7v14"/><path d="M6 21h12"/><path d="M6 13h10"/>',
  'clock': '<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
  'phone': '<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>',
  'recycle': '<path d="M3 12a9 9 0 0 1 15.5-6.2L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-15.5 6.2L3 16"/><path d="M3 21v-5h5"/>',
  'badge-check': '<path d="M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76z"/><path d="m9 12 2 2 4-4"/>',
  'home': '<path d="M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8"/><path d="M3 10a2 2 0 0 1 .709-1.528l7-5.999a2 2 0 0 1 2.582 0l7 5.999A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
  'menu': '<path d="M4 6h16M4 12h16M4 18h16"/>',
  'x': '<path d="M18 6 6 18M6 6l12 12"/>',
  'check': '<path d="M20 6 9 17l-5-5"/>',
  'check-circle': '<path d="M21.8 10A10 10 0 1 1 17 3.34"/><path d="m9 11 3 3L22 4"/>',
  'chev-l': '<path d="m15 18-6-6 6-6"/>', 'chev-r': '<path d="m9 18 6-6-6-6"/>', 'chev-d': '<path d="m6 9 6 6 6-6"/>',
  'pin': '<path d="M20 10c0 4.99-5.54 10.19-7.4 11.8a1 1 0 0 1-1.2 0C9.54 20.19 4 14.99 4 10a8 8 0 0 1 16 0"/><circle cx="12" cy="10" r="3"/>',
  'info': '<circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/>',
  'alert': '<path d="M12 9v4M12 17h.01"/><path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/>',
  'alert-c': '<circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/>',
  'wrench': '<path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94z"/>',
  'boiler': '<rect x="5" y="2" width="14" height="17" rx="3"/><circle cx="12" cy="10.5" r="3"/><path d="M8.5 19v3M12 19v3M15.5 19v3"/>',
  'clipboard': '<rect width="8" height="4" x="8" y="2" rx="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><path d="m9 14 2 2 4-4"/>',
  'file-check': '<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><path d="m9 15 2 2 4-4"/>',
  'droplets': '<path d="M7 16.3c2.2 0 4-1.83 4-4.05 0-1.16-.57-2.26-1.71-3.19S7.29 6.75 7 5.3c-.29 1.45-1.14 2.84-2.29 3.76S3 11.1 3 12.25c0 2.22 1.8 4.05 4 4.05z"/><path d="M12.56 6.6A10.97 10.97 0 0 0 14 3.02c.5 2.5 2 4.9 4 6.5s3 3.5 3 5.5a6.98 6.98 0 0 1-11.91 4.97"/>',
  'thermometer': '<path d="M14 4v10.54a4 4 0 1 1-4 0V4a2 2 0 0 1 4 0z"/>',
  'radiator': '<rect x="3" y="5" width="18" height="12" rx="2"/><path d="M8 5v12M12 5v12M16 5v12M6 17v3M18 17v3"/>'
};
const ico = (n, cls = '') => `<svg class="ico ${cls}" viewBox="0 0 24 24" aria-hidden="true" focusable="false">${ICONS[n] || ''}</svg>`;
function hydrateIcons(root = document) {
  $$('i[data-ico]', root).forEach(i => {
    const t = document.createElement('span'); t.innerHTML = ico(i.dataset.ico, `${i.className} ${i.dataset.cls || ''}`.trim());
    i.replaceWith(t.firstChild);
  });
}

/* ---------- illustrations (original vector art, placeholders) ---------- */
function rng(seed) { return () => { seed |= 0; seed = seed + 0x6D2B79F5 | 0; let t = Math.imul(seed ^ seed >>> 15, 1 | seed); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
const sceneBefore = () => `<img class="scene before" src="${BEFORE_PHOTO}" alt="Before: an old, rusty boiler with tired pipework and damp-stained walls" draggable="false">`;
const sceneAfter = () => `<img class="scene after" src="${AFTER_PHOTO}" alt="After: a new wall-mounted boiler with neat copper pipework and a smart thermostat" draggable="false">`;
/* ---------- ambient background shapes + animated dividers ---------- */
function buildAmbient(variant, density, seed) {
  const r = rng(seed), dark = variant === 'dark', hi = density === 'high';
  const nC = hi ? 8 : 2, nL = hi ? 4 : 1;
  const cols = dark ? [['234,88,12', .08, .15], ['255,255,255', .04, .08]] : [['15,41,66', .03, .06], ['234,88,12', .05, .08]];
  const pipes = ['M2 20H140a18 18 0 0 1 18 18V120a18 18 0 0 0 18 18H318', 'M2 150V70a18 18 0 0 1 18-18H200a18 18 0 0 1 18 18V138', 'M2 8H330', 'M2 100C90 10 190 190 328 90'];
  let html = '';
  for (let i = 0; i < nC; i++) {
    const [rgb, a0, a1] = cols[Math.floor(r() * cols.length)], a = a0 + r() * (a1 - a0), s = 70 + r() * 270, ring = r() > .5;
    const dx = (r() > .5 ? 1 : -1) * (30 + r() * 30), dy = (r() > .5 ? 1 : -1) * (30 + r() * 30);
    html += `<span class="sh c ${ring ? 'ring' : 'fill'} ${i >= nC / 2 ? 'dsk' : ''}" style="left:${(r() * 100 - 6).toFixed(1)}%;top:${(hi ? r() * 100 - 8 : 14 + r() * 50).toFixed(1)}%;width:${(hi ? s : Math.min(s, 200)).toFixed(0)}px;height:${(hi ? s : Math.min(s, 200)).toFixed(0)}px;color:rgba(${rgb},${a.toFixed(3)});${ring ? '' : `filter:blur(${s > 180 ? 28 : 12}px);`}--dx:${dx.toFixed(0)}px;--dy:${dy.toFixed(0)}px;--rot:${(r() * 14 - 7).toFixed(1)}deg;--dur:${(18 + r() * 22).toFixed(1)}s;--delay:-${(r() * 30).toFixed(1)}s"></span>`;
  }
  for (let i = 0; i < nL; i++) {
    const [rgb, a0, a1] = cols[Math.floor(r() * cols.length)], a = a0 + r() * (a1 - a0), w = 260 + r() * 160, p = pipes[(i + Math.floor(r() * 4)) % 4];
    const dx = (r() > .5 ? 1 : -1) * (30 + r() * 30), dy = (r() > .5 ? 1 : -1) * (20 + r() * 30);
    html += `<span class="sh ln ${i >= nL / 2 ? 'dsk' : ''}" style="left:${(r() * 80).toFixed(1)}%;top:${(hi ? r() * 85 : 15 + r() * 55).toFixed(1)}%;width:${w.toFixed(0)}px;height:${(w * .45).toFixed(0)}px;color:rgba(${rgb},${Math.max(a, .06).toFixed(3)});--dx:${dx.toFixed(0)}px;--dy:${dy.toFixed(0)}px;--rot:${(r() * 8 - 4).toFixed(1)}deg;--dur:${(20 + r() * 20).toFixed(1)}s;--delay:-${(r() * 30).toFixed(1)}s"><svg viewBox="0 0 330 150" preserveAspectRatio="none"><path d="${p}"/></svg></span>`;
  }
  return html;
}
function initAmbient() {
  $$('[data-amb]').forEach((sec, i) => {
    const [v, d] = sec.dataset.amb.split(':');
    const el = document.createElement('div'); el.className = 'amb'; el.setAttribute('aria-hidden', 'true'); el.innerHTML = buildAmbient(v, d, 7 + i * 13);
    sec.appendChild(el);
  });
}
const COL = { navy: '#0F2942', ice: '#F8FAFC', white: '#FFFFFF' };
function initDividers() {
  $$('[data-divider]').forEach(el => {
    const from = COL[el.dataset.from], to = COL[el.dataset.to], dark = el.dataset.tone === 'dark';
    const wrap = document.createElement('div');
    if (el.dataset.divider === 'wave') {
      wrap.innerHTML = `<div class="div-wave" style="--from:${from};--to:${to}" aria-hidden="true"><svg viewBox="0 0 2400 80" preserveAspectRatio="none"><path d="M0 40Q300 0 600 40T1200 40T1800 40T2400 40V80H0Z"/></svg></div>`;
    } else {
      wrap.innerHTML = `<div class="div-line" style="--from:${from};--to:${to};--stroke:${dark ? 'rgba(255,255,255,.22)' : 'rgba(15,41,66,.18)'}" aria-hidden="true"><div class="in"><svg><line x1="0" y1="1" x2="100%" y2="1" pathLength="100"/></svg><i class="dot"></i></div></div>`;
    }
    el.replaceWith(wrap.firstChild);
  });
}

/* ---------- image slots: use real photos when SITE.images[id].src is set ---------- */
function initImages() {
  $$('svg[data-img]').forEach(svg => {
    const c = SITE.images[svg.dataset.img]; if (!c) return;
    svg.setAttribute('aria-label', c.alt);
    if (c.src) {
      const img = document.createElement('img');
      Object.assign(img, { src: c.src, alt: c.alt, width: c.width, height: c.height, loading: svg.dataset.img === 'hero' ? 'eager' : 'lazy' });
      img.className = svg.getAttribute('class') || ''; img.style.cssText = `width:100%;height:100%;object-fit:cover;object-position:${c.focal}`;
      svg.replaceWith(img);
    }
  });
}

/* =====================================================================
   QUOTE CONNECTOR (mocked, production-shaped)
   Typed schema + discriminated-union result. Never throws to the UI.
   Prototype: simulates latency and returns success. NOTHING is sent,
   stored or logged outside this browser tab.

   Equivalent zod schema for the real build (src/lib/quote-connector.ts):
     export const QuoteRequestSchema = z.object({
       need: z.enum(['no-heating','no-hot-water','leak-noise','service','new']),
       pkg: z.enum(['essential','comfort','premium','not-sure']).optional(),
       postcode: z.string().trim().regex(UK_POSTCODE),
       urgency: z.enum(['today','week','planning']),
       name: z.string().trim().min(2).max(80),
       mobile: z.string().trim().refine(isUkMobile),
       note: z.string().trim().max(500).optional(),
     });
     export type QuoteRequest = z.infer<typeof QuoteRequestSchema>;
     export type QuoteResult =
       | { status: 'success'; reference: string; receivedAt: string }
       | { status: 'validation_error'; fieldErrors: Partial<Record<keyof QuoteRequest, string>> }
       | { status: 'network_error'; message: string; retryable: boolean };
   ===================================================================== */
const UK_POSTCODE = /^(GIR ?0AA|[A-PR-UWYZ]([0-9]{1,2}|([A-HK-Y][0-9]([0-9ABEHMNPRV-Y])?)|[0-9][A-HJKPS-UW]) ?[0-9][ABD-HJLNP-UW-Z]{2})$/i;
const isUkMobile = v => /^(?:\+44|0044|0)7\d{9}$/.test(String(v).replace(/[\s()-]/g, ''));
const NEED_IDS = SITE.needs.map(n => n.id), URG_IDS = SITE.urgency.map(u => u.id), PKG_IDS = ['essential', 'comfort', 'premium', 'not-sure'];
const FIELD_RULES = {
  need: v => NEED_IDS.includes(v) ? null : 'Please choose what you need.',
  pkg: v => !v || PKG_IDS.includes(v) ? null : 'Please choose a package.',
  postcode: v => UK_POSTCODE.test(String(v).trim()) ? null : 'Enter a valid UK postcode, like BS3 4AB.',
  urgency: v => URG_IDS.includes(v) ? null : 'Please choose how urgent it is.',
  name: v => { const t = String(v).trim(); return t.length < 2 ? 'Please tell us your name.' : t.length > 80 ? 'That name looks too long.' : null; },
  mobile: v => isUkMobile(v) ? null : 'Enter a UK mobile number, like 07700 900123.',
  note: v => String(v || '').length > 500 ? 'Please keep your note under 500 characters.' : null
};
const QuoteRequestSchema = {
  fields: Object.keys(FIELD_RULES),
  safeParse(input, only) {
    const fieldErrors = {}, keys = only || this.fields;
    for (const k of keys) { const e = FIELD_RULES[k](input?.[k] ?? ''); if (e) fieldErrors[k] = e; }
    if (Object.keys(fieldErrors).length) return { success: false, error: { fieldErrors } };
    const d = { ...input };
    d.postcode = String(d.postcode || '').replace(/\s+/g, '').toUpperCase().replace(/^(.+)(.{3})$/, '$1 $2');
    return { success: true, data: d };
  }
};
const wait = ms => new Promise(r => setTimeout(r, ms));
async function submitQuote(input, opts = {}) {
  try {
    const parsed = QuoteRequestSchema.safeParse(input);
    if (!parsed.success) return { status: 'validation_error', fieldErrors: parsed.error.fieldErrors };
    // ---- PLUG A REAL ENDPOINT IN HERE --------------------------------
    // e.g. const res = await fetch('https://your-form-service.example/submit', {
    //        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(parsed.data) });
    //      if (!res.ok) return { status: 'network_error', message: `Server replied ${res.status}`, retryable: res.status >= 500 };
    // Prototype only: simulate latency. No request is made, nothing is stored or logged.
    await wait(900 + Math.random() * 600);
    if (opts.simulateFailure) throw new Error('Simulated connection problem (demonstration)');
    // -------------------------------------------------------------------
    return { status: 'success', reference: 'DEMO-' + Math.random().toString(36).slice(2, 8).toUpperCase(), receivedAt: new Date().toISOString() };
  } catch (err) {
    return { status: 'network_error', message: err instanceof Error ? err.message : 'Unknown error', retryable: true };
  }
}

/* ---------- quote form component (modal + inline share this) ---------- */
function createQuoteForm(root, { uid, prefill = {}, onSuccess } = {}) {
  const S = { step: 1, status: 'idle', errors: {}, demoFail: false, banner: '',
    data: { need: prefill.need || '', pkg: prefill.pkg || '', postcode: '', urgency: '', name: '', mobile: '', note: '' } };
  const id = n => `${uid}-${n}`;
  const errHtml = k => S.errors[k] ? `<p class="err" id="${id('e-' + k)}" role="alert">${ico('alert-c')}<span>${esc(S.errors[k])}</span></p>` : '';
  const radio = (name, val, label, icon, checked) => `<label class="opt"><input type="radio" name="${name}" value="${val}" ${checked ? 'checked' : ''}><span class="c">${icon ? ico(icon) : ''}<span>${esc(label)}</span></span></label>`;

  function stepHtml() {
    const d = S.data;
    if (S.step === 1) return `<fieldset aria-describedby="${S.errors.need ? id('e-need') : ''}">
      <legend class="q-title" tabindex="-1">What do you need?</legend><p class="q-sub">Pick the closest match. You can add detail later.</p>
      <div class="opts">${SITE.needs.map(n => radio('need', n.id, n.label, n.ico, d.need === n.id)).join('')}</div>${errHtml('need')}
      <div class="pk-pick" id="${id('pkpick')}" ${d.need === 'new' ? '' : 'hidden'}><span class="lbl">Which package are you interested in?</span>
        <div class="opts pk4">${[...SITE.packages.map(p => [p.id, p.name]), ['not-sure', 'Not sure yet']].map(([v, l]) => radio('pkg', v, l, '', d.pkg === v)).join('')}</div></div></fieldset>`;
    if (S.step === 2) return `<div><h3 class="q-title" tabindex="-1">Where are you, and how urgent is it?</h3><p class="q-sub">We use your postcode to check we cover you.</p>
      <div class="fld"><label class="lb" for="${id('postcode')}">UK postcode</label>
        <input class="in-t" id="${id('postcode')}" name="postcode" type="text" autocomplete="postal-code" autocapitalize="characters" spellcheck="false" placeholder="e.g. BS3 4AB" value="${esc(d.postcode)}" ${S.errors.postcode ? `aria-invalid="true" aria-describedby="${id('e-postcode')}"` : ''}>${errHtml('postcode')}</div>
      <fieldset class="fld" ${S.errors.urgency ? `aria-describedby="${id('e-urgency')}"` : ''}><legend class="lb" style="font:700 .9375rem/1.2 var(--font-h);margin-bottom:8px">How urgent?</legend>
        <div class="opts pills">${SITE.urgency.map(u => radio('urgency', u.id, u.label, '', d.urgency === u.id)).join('')}</div>${errHtml('urgency')}</fieldset></div>`;
    return `<div><h3 class="q-title" tabindex="-1">Last step: how do we reach you?</h3><p class="q-sub">Callum or one of the team will call within the hour.</p>
      <div class="fld"><label class="lb" for="${id('name')}">Your name</label><input class="in-t" id="${id('name')}" name="name" type="text" autocomplete="name" value="${esc(d.name)}" ${S.errors.name ? `aria-invalid="true" aria-describedby="${id('e-name')}"` : ''}>${errHtml('name')}</div>
      <div class="fld"><label class="lb" for="${id('mobile')}">Mobile number</label><input class="in-t" id="${id('mobile')}" name="mobile" type="tel" inputmode="tel" autocomplete="tel" placeholder="07700 900123" value="${esc(d.mobile)}" ${S.errors.mobile ? `aria-invalid="true" aria-describedby="${id('e-mobile')}"` : ''}>${errHtml('mobile')}</div>
      <div class="fld"><label class="lb" for="${id('note')}">Anything we should know? <em>(optional)</em></label><textarea class="in-t" id="${id('note')}" name="note" rows="3" ${S.errors.note ? `aria-invalid="true" aria-describedby="${id('e-note')}"` : ''}>${esc(d.note)}</textarea>${errHtml('note')}</div>
      <label class="demo-opt"><input type="checkbox" name="demoFail" ${S.demoFail ? 'checked' : ''}><span>Demo only: simulate a connection error on the first try, to see the retry state.</span></label></div>`;
  }
  function successHtml() {
    const first = esc((S.data.name.trim().split(/\s+/)[0]) || 'there');
    return `<div class="ok" role="status"><div class="big">${ico('check')}</div><h3 tabindex="-1" id="${id('ok')}">Thanks ${first}, Callum will call you within the hour.</h3>
      <p>Your quote request has been received. Fixed price, agreed before any work starts.</p><span class="demo-flag">Demonstration only: no data was sent.</span>
      <button type="button" class="again" data-act="again">Start another request</button></div>`;
  }
  function render(focus) {
    if (S.status === 'success') { root.innerHTML = `<div class="qf" aria-live="polite">${successHtml()}</div>`; if (focus) $('h3', root).focus({ preventScroll: false }); return; }
    const busy = S.status === 'loading', last = S.step === 3, pct = S.step / 3;
    const label = busy ? `<span class="spin" aria-hidden="true"></span><span>Sending…</span>` : last ? (S.status === 'error' ? 'Try again' : 'Get Your Free Quote') : 'Continue';
    root.innerHTML = `<form class="qf" novalidate aria-label="Free quote request">
      <div class="qf-top"><span>Step ${S.step} of 3</span><span>${['What you need', 'Where & when', 'Your details'][S.step - 1]}</span></div>
      <div class="bar" role="progressbar" aria-valuemin="1" aria-valuemax="3" aria-valuenow="${S.step}" aria-label="Quote form progress"><i style="--p:${pct}"></i></div>
      ${S.status === 'error' ? `<div class="banner-err" role="alert">${ico('alert-c')}<div><b>We couldn’t send that just now</b>${esc(S.banner)} Your details are still here. Press “Try again”, or call <a href="tel:+447340845320" style="color:inherit;font-weight:700">${SITE.business.phone}</a>.</div></div>` : ''}
      <div class="step-anim" data-step="${S.step}">${stepHtml()}</div>
      <div class="qf-nav">${S.step > 1 ? `<button type="button" class="back" data-act="back" ${busy ? 'disabled' : ''}>${ico('chev-l')}Back</button>` : ''}
        <button type="submit" class="cta" ${busy ? 'disabled aria-busy="true"' : ''}>${label}</button></div></form>`;
    if (focus === 'step') $('.q-title', root)?.focus({ preventScroll: true });
    else if (focus === 'error') { const bad = $('[aria-invalid="true"]', root) || $('fieldset .opt input', root); bad?.focus(); }
  }
  function collect() { /* data is kept in sync by the input handlers */ }
  function validateStep() {
    const keys = [['need', 'pkg'], ['postcode', 'urgency'], ['name', 'mobile', 'note']][S.step - 1];
    const r = QuoteRequestSchema.safeParse(S.data, keys); S.errors = r.success ? {} : r.error.fieldErrors; return r.success;
  }
  async function submit() {
    S.status = 'loading'; S.errors = {}; render();
    const res = await submitQuote(S.data, { simulateFailure: S.demoFail });
    if (res.status === 'success') { S.status = 'success'; render('step'); onSuccess?.(S.data, res); }
    else if (res.status === 'validation_error') { S.status = 'idle'; S.errors = res.fieldErrors; S.step = ['need', 'pkg'].some(k => S.errors[k]) ? 1 : ['postcode', 'urgency'].some(k => S.errors[k]) ? 2 : 3; render('error'); }
    else { S.status = 'error'; S.demoFail = false; S.banner = res.retryable ? '' : res.message; render(); $('.banner-err', root)?.scrollIntoView({ block: 'nearest' }); }
  }
  root.addEventListener('submit', e => {
    e.preventDefault(); if (S.status === 'loading') return;
    if (!validateStep()) { render('error'); return; }
    if (S.step < 3) { S.step++; S.status = 'idle'; render('step'); } else submit();
  });
  root.addEventListener('click', e => {
    const b = e.target.closest('[data-act]'); if (!b) return;
    if (b.dataset.act === 'back') { S.step = Math.max(1, S.step - 1); S.errors = {}; S.status = 'idle'; render('step'); }
    if (b.dataset.act === 'again') { S.step = 1; S.status = 'idle'; S.errors = {}; S.data = { need: '', pkg: '', postcode: '', urgency: '', name: '', mobile: '', note: '' }; render('step'); }
  });
  root.addEventListener('input', e => { const t = e.target; if (t.name && t.name in S.data && t.type !== 'radio') { S.data[t.name] = t.value; if (S.errors[t.name]) { delete S.errors[t.name]; $(`#${id('e-' + t.name)}`, root)?.remove(); t.removeAttribute('aria-invalid'); } } });
  root.addEventListener('change', e => {
    const t = e.target;
    if (t.name === 'demoFail') { S.demoFail = t.checked; return; }
    if (t.type === 'radio') {
      S.data[t.name] = t.value; delete S.errors[t.name]; $(`#${id('e-' + t.name)}`, root)?.remove();
      if (t.name === 'need') { const pk = $(`#${id('pkpick')}`, root); if (pk) pk.hidden = t.value !== 'new'; if (t.value !== 'new') S.data.pkg = ''; }
      /* step 1: advance automatically once a choice is made (brief pause so the selection is seen) */
      if (S.step === 1 && S.status !== 'loading' && ((t.name === 'need' && t.value !== 'new') || t.name === 'pkg')) {
        const at = S.step; clearTimeout(S.auto);
        S.auto = setTimeout(() => { if (S.step === at && validateStep()) { S.step++; S.status = 'idle'; render('step'); } }, 280);
      }
    }
  });
  root.addEventListener('blur', e => { const t = e.target; if (t.name === 'postcode' && t.value.trim() && UK_POSTCODE.test(t.value.trim())) { t.value = t.value.replace(/\s+/g, '').toUpperCase().replace(/^(.+)(.{3})$/, '$1 $2'); S.data.postcode = t.value; } }, true);
  render();
  return { focusFirst: () => ($('.q-title', root) || root).focus({ preventScroll: true }) };
}

/* ---------- renderers for content sections ---------- */
function renderContent() {
  $('#svcGrid').innerHTML = SITE.services.map(s => `<article class="card svc"><div class="svc-ic">${ico(s.ico)}</div><h3>${esc(s.title)}</h3><p class="ben">${esc(s.benefit)}</p>
    <ul class="ticks">${s.features.map(f => `<li>${ico('check')}<span>${esc(f)}</span></li>`).join('')}</ul>
    <div class="price"><small>From</small><b>${s.price}</b>${s.priceNote ? `<span>${esc(s.priceNote)}</span>` : ''}</div></article>`).join('');
  $('#incList').innerHTML = SITE.included.map((t, i) => `<li><span class="inc-ic">${ico(SITE.includedIcons[i] || 'check')}</span><span>${esc(t)}</span></li>`).join('');
  $('#pkGrid').innerHTML = SITE.packages.map(p => `<article class="card pk ${p.popular ? 'pop' : ''}" ${p.popular ? 'aria-label="Comfort, most popular"' : ''}>${p.popular ? '<span class="tag">Most popular</span>' : ''}
    <h3>${p.name}</h3><p class="desc">${esc(p.blurb)}</p><div class="amt"><small>from</small><b>${p.price}</b></div><p class="fix">Fixed price confirmed after a free survey</p>
    <ul class="ticks">${p.features.map(f => `<li>${ico('check')}<span>${esc(f)}</span></li>`).join('')}</ul></article>`).join('');
  $('#prGrid').innerHTML = SITE.promise.map(([t, d]) => `<div class="pr">${ico('shield-check')}<h3>${esc(t)}</h3><p>${esc(d)}</p></div>`).join('');
  $('#stepGrid').innerHTML = SITE.steps.map(([t, d], i) => `<li class="step"><span class="num" aria-hidden="true">${i + 1}</span><div><h3>${esc(t)}</h3><p>${esc(d)}</p></div></li>`).join('');
  $('#arGrid').innerHTML = SITE.areas.map(a => `<div class="card ar"><span class="pin">${ico('pin')}</span><div><b>${a}</b><span>${esc(SITE.areaNotes[a] || '')}</span></div></div>`).join('');
  $('#ftrAreas').textContent = SITE.areas.join(', ');
  $('#faqList').innerHTML = SITE.faq.map(([q, a], i) => `<div class="fq ${i === 0 ? 'open' : ''}"><h3><button type="button" id="fqb${i}" aria-expanded="${i === 0}" aria-controls="fqp${i}"><span>${esc(q)}</span>${ico('chev-d')}</button></h3>
    <div class="pnl" id="fqp${i}" role="region" aria-labelledby="fqb${i}"><div><p>${esc(a)}</p></div></div></div>`).join('');
  $('#rvTrack').innerHTML = SITE.reviews.map((r, i) => `<article class="card rev" role="group" aria-roledescription="slide" aria-label="${i + 1} of ${SITE.reviews.length}">
    <div class="st" role="img" aria-label="5 out of 5 stars">${ico('star').repeat(5)}</div><blockquote>“${esc(r.text)}”</blockquote>
    <div class="who"><b>${esc(r.name)}</b><span>${esc(r.town)}</span></div><div class="tags"><span class="tag-j">${esc(r.job)}</span></div></article>`).join('');

  const c = SITE.caseStudy;
  $('#case').innerHTML = `<div class="cmp" id="cmp" style="--pos:50%">${sceneAfter()}${sceneBefore()}
      <span class="lab b">BEFORE</span><span class="lab a">AFTER</span>
      <input type="range" min="0" max="100" value="50" step="1" id="cmpRange" aria-label="Before and after comparison. Use the arrow keys to move the divider." aria-valuetext="Showing 50% before, 50% after">
      <div class="handle" aria-hidden="true"><span class="knob">${ico('chev-l')}${ico('chev-r')}</span></div></div>
    <div class="case-body"><h3>${esc(c.title)}</h3>
      <dl><div><dt>Situation (before)</dt><dd>${esc(c.before)}</dd></div><div><dt>What we did</dt><dd>${esc(c.did)}</dd></div></dl>
      <div class="stats">${c.stats.map(([i, big, small]) => `<div class="stat"><span class="stat-ic">${ico(i)}</span><b>${esc(big)}</b><span class="stat-s">${esc(small)}</span></div>`).join('')}</div></div>`;
}

/* ---------- interactions ---------- */
function initCompare() {
  const cmp = $('#cmp'), rng_ = $('#cmpRange');
  const set = () => { const v = +rng_.value; cmp.style.setProperty('--pos', v + '%'); rng_.setAttribute('aria-valuetext', `Showing ${v}% before, ${100 - v}% after`); };
  rng_.addEventListener('input', set); set();
}
function initFaq() {
  $('#faqList').addEventListener('click', e => {
    const b = e.target.closest('button[aria-expanded]'); if (!b) return;
    const open = b.getAttribute('aria-expanded') === 'true';
    b.setAttribute('aria-expanded', String(!open)); b.closest('.fq').classList.toggle('open', !open);
  });
}
function initCarousel() {
  const track = $('#rvTrack'), cards = [...track.children], n = cards.length, prev = $('#rvPrev'), next = $('#rvNext'), live = $('#rvLive');
  const pv = () => parseInt(getComputedStyle(track).getPropertyValue('--pv')) || 1;
  const stepPx = () => cards[0].getBoundingClientRect().width + (parseFloat(getComputedStyle(track).columnGap) || 0);
  const maxIdx = () => Math.max(0, n - pv());
  const idx = () => Math.min(maxIdx(), Math.max(0, Math.round(track.scrollLeft / stepPx())));
  const goTo = i => track.scrollTo({ left: Math.min(maxIdx(), Math.max(0, i)) * stepPx(), behavior: reduced ? 'auto' : 'smooth' });
  let announce;
  function update() {
    const i = idx(), p = pv();
    prev.disabled = track.scrollLeft <= 2; next.disabled = track.scrollLeft >= track.scrollWidth - track.clientWidth - 2;
    clearTimeout(announce); announce = setTimeout(() => { live.textContent = p === 1 ? `Showing review ${i + 1} of ${n}` : `Showing reviews ${i + 1} to ${Math.min(n, i + p)} of ${n}`; }, 350);
  }
  prev.addEventListener('click', () => goTo(idx() - 1)); next.addEventListener('click', () => goTo(idx() + 1));
  track.addEventListener('keydown', e => { if (e.key === 'ArrowRight') { e.preventDefault(); goTo(idx() + 1); } if (e.key === 'ArrowLeft') { e.preventDefault(); goTo(idx() - 1); } });
  let raf; track.addEventListener('scroll', () => { cancelAnimationFrame(raf); raf = requestAnimationFrame(update); }, { passive: true });
  addEventListener('resize', update); update();
}

/* modal + toast + header + sticky bar */
const page = $('#page'), modal = $('#modal'), dialog = $('#dialog'), sbar = $('#sbar'), toast = $('#toast');
let lastFocus = null, toastT;
function showToast(t, s) { $('#toastT').textContent = t; $('#toastS').textContent = s; toast.classList.add('show'); clearTimeout(toastT); toastT = setTimeout(() => toast.classList.remove('show'), 6500); }
function openQuote(pre = {}) {
  lastFocus = document.activeElement; closeNav();
  const prefill = pre.pkg ? { need: 'new', pkg: pre.pkg } : {};
  const old = $('#modalForm'), fresh = old.cloneNode(false); old.replaceWith(fresh);
  const mf = createQuoteForm(fresh, { uid: 'm', prefill, onSuccess: (d) => showToast('Quote request received', 'Demonstration only: no data was sent.') });
  modal.classList.add('open'); modal.setAttribute('aria-hidden', 'false'); page.inert = true; sbar.inert = true;
  document.documentElement.style.overflow = 'hidden'; dialog.scrollTop = 0;
  requestAnimationFrame(() => mf.focusFirst());
}
function closeQuote() {
  if (!modal.classList.contains('open')) return;
  modal.classList.remove('open'); modal.setAttribute('aria-hidden', 'true'); page.inert = false; sbar.inert = false;
  document.documentElement.style.overflow = ''; $('#modalForm').innerHTML = '';
  if (lastFocus && document.contains(lastFocus)) lastFocus.focus({ preventScroll: true });
}
const closeNav = () => { $('#mnav').classList.remove('open'); const b = $('#burger'); b.setAttribute('aria-expanded', 'false'); b.setAttribute('aria-label', 'Open menu'); };
function initUI() {
  document.addEventListener('click', e => {
    const q = e.target.closest('[data-quote]'); if (q) { openQuote({ pkg: q.dataset.pkg }); return; }
    if (e.target.closest('[data-close]') || e.target.closest('#mdClose')) { closeQuote(); return; }
    const top = e.target.closest('[data-top]'); if (top) { e.preventDefault(); closeNav(); scrollTo({ top: 0, behavior: reduced ? 'auto' : 'smooth' }); return; }
    const a = e.target.closest('a[href^="#"]'); if (a && a.getAttribute('href').length > 1) {
      const t = document.getElementById(a.getAttribute('href').slice(1)); if (t) { e.preventDefault(); closeNav(); t.scrollIntoView({ behavior: reduced ? 'auto' : 'smooth', block: 'start' }); }
    }
  });
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') { if (modal.classList.contains('open')) closeQuote(); else if ($('#mnav').classList.contains('open')) { closeNav(); $('#burger').focus(); } }
    if (e.key === 'Tab' && modal.classList.contains('open')) {
      const f = $$('button:not([disabled]),input:not([disabled]),textarea,a[href],[tabindex]:not([tabindex="-1"])', dialog).filter(el => el.offsetParent !== null || el === document.activeElement);
      if (!f.length) return; const first = f[0], last = f[f.length - 1];
      if (e.shiftKey && (document.activeElement === first || !dialog.contains(document.activeElement))) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    }
  });
  $('#burger').addEventListener('click', () => { const o = !$('#mnav').classList.contains('open'); $('#mnav').classList.toggle('open', o); $('#burger').setAttribute('aria-expanded', String(o)); $('#burger').setAttribute('aria-label', o ? 'Close menu' : 'Open menu'); });
  /* header compaction + sticky mobile bar */
  const hdr = $('#hdr'), hero = $('#hero'), sbtn = $('.cta', sbar); let tick = false;
  const onScroll = () => { tick = false; hdr.classList.toggle('compact', scrollY > 40); const past = hero.getBoundingClientRect().bottom < 0; sbar.classList.toggle('show', past); sbtn.tabIndex = past ? 0 : -1; $('.sbar-call', sbar).tabIndex = past ? 0 : -1; };
  addEventListener('scroll', () => { if (!tick) { tick = true; requestAnimationFrame(onScroll); } }, { passive: true }); onScroll();
  /* CTA glow follows the cursor (hover devices, not reduced motion) */
  if (!reduced) document.addEventListener('pointermove', e => {
    if (e.pointerType === 'touch') return; const b = e.target.closest?.('.cta'); if (!b) return;
    const r = b.getBoundingClientRect(); b.style.setProperty('--x', (e.clientX - r.left) + 'px'); b.style.setProperty('--y', (e.clientY - r.top) + 'px');
  }, { passive: true });
}
function initObservers() {
  const io = new IntersectionObserver(es => es.forEach(en => en.target.classList.toggle('paused', !en.isIntersecting)), { rootMargin: '120px 0px' });
  $$('[data-amb], .div-wave').forEach(el => io.observe(el));
  const dv = new IntersectionObserver(es => es.forEach(en => { if (en.isIntersecting) { en.target.classList.add('in-view'); dv.unobserve(en.target); } }), { threshold: .7 });
  $$('.div-line').forEach(el => dv.observe(el));
}

/* ---------- boot ---------- */
function boot() {
  document.documentElement.style.setProperty('--hero-photo', `url("${SITE.images.heroBg.src}")`);
  renderContent(); initDividers(); initImages();
  createQuoteForm($('#inlineForm'), { uid: 'i', onSuccess: () => showToast('Quote request received', 'Demonstration only: no data was sent.') });
  hydrateIcons(); initAmbient(); initCompare(); initFaq(); initCarousel(); initUI(); initObservers();
}
boot();
