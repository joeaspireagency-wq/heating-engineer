cd "$(dirname "$0")"
{ cat <<'HEAD'
<!DOCTYPE html>
<html lang="en-GB">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Reeves Heating &amp; Gas | Gas Safe boiler repair, Bristol &amp; Bath (prototype)</title>
<meta name="description" content="Prototype website for a fictional Gas Safe heating engineer in Bristol and Bath. Fixed-price boiler repairs, installs and servicing.">
<meta name="theme-color" content="#0F2942">
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Caveat:wght@600&family=Inter:wght@400;500;600&family=Plus+Jakarta+Sans:wght@600;700;800&display=swap" rel="stylesheet">
<style>
HEAD
cat style.css
cat <<'MID'
</style>
</head>
<body>
MID
cat body.html
echo '<script>'
cat photo.js
cat app.js
echo '</script></body></html>'
} > index.html
wc -c index.html
